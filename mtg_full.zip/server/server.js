
import express from "express";
import http from "http";
import { Server } from "socket.io";

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });

const rooms = {};

function createRoom() {
  return {
    players: [],
    state: {
      battlefield: [],
      graveyard: [],
      hands: {},
      decks: {},
      manaPool: {},
      landsPlayed: {}
    },
    turn: { order: [], currentIndex: 0, phase: "draw" },
    stack: [],
    priority: { order: [], currentIndex: 0, passes: 0 }
  };
}

function getCurrentPlayer(room){
  return room.turn.order[room.turn.currentIndex];
}

function startPriority(room){
  room.priority.order = [...room.turn.order];
  room.priority.currentIndex = room.turn.currentIndex;
  room.priority.passes = 0;
}

function canPayCost(pool, cost){
  const temp = {...pool};
  for (let c of ["W","U","B","R","G"]) {
    if ((cost[c]||0) > (temp[c]||0)) return false;
    temp[c] -= cost[c]||0;
  }
  let generic = cost.C||0;
  for (let c of ["W","U","B","R","G","C"]) {
    const used = Math.min(temp[c], generic);
    temp[c] -= used;
    generic -= used;
  }
  return generic===0;
}

function payCost(pool, cost){
  for (let c of ["W","U","B","R","G"]) pool[c] -= cost[c]||0;
  let generic = cost.C||0;
  for (let c of ["W","U","B","R","G","C"]) {
    const used = Math.min(pool[c], generic);
    pool[c] -= used;
    generic -= used;
  }
}

function resolveStack(room){
  const item = room.stack.pop();
  if(!item) return;
  const {card, target} = item;

  if(card.type === "creature"){
    room.state.battlefield.push(card);
    return;
  }

  if(card.effect?.type === "damage"){
    const player = room.players.find(p=>p.id===target);
    if(player) player.life -= card.effect.amount;
  }

  room.state.graveyard.push(card);
}

io.on("connection", socket => {

  socket.on("joinRoom", ({roomId,name})=>{
    if(!rooms[roomId]) rooms[roomId] = createRoom();
    const room = rooms[roomId];

    room.players.push({id:socket.id,name,life:40});
    room.turn.order.push(socket.id);

    room.state.hands[socket.id] = [];
    room.state.decks[socket.id] = [];
    room.state.manaPool[socket.id] = {W:0,U:0,B:0,R:0,G:0,C:0};
    room.state.landsPlayed[socket.id] = false;

    socket.join(roomId);
    emitRoom(roomId);
  });

  socket.on("setDeck", ({roomId,deck})=>{
    rooms[roomId].state.decks[socket.id] = deck;
  });

  socket.on("draw", ({roomId})=>{
    const room = rooms[roomId];
    const deck = room.state.decks[socket.id];
    if(deck.length) room.state.hands[socket.id].push(deck.pop());
    emitRoom(roomId);
  });

  socket.on("playLand", ({roomId,cardId})=>{
    const room = rooms[roomId];
    if(room.state.landsPlayed[socket.id]) return;

    const hand = room.state.hands[socket.id];
    const i = hand.findIndex(c=>c.id===cardId);
    if(i===-1) return;

    const [card] = hand.splice(i,1);
    room.state.battlefield.push(card);
    room.state.landsPlayed[socket.id]=true;

    emitRoom(roomId);
  });

  socket.on("tapLand", ({roomId,cardId,color})=>{
    const room = rooms[roomId];
    const land = room.state.battlefield.find(c=>c.id===cardId);
    if(!land || land.tapped) return;

    land.tapped = true;
    room.state.manaPool[socket.id][color]++;
    emitRoom(roomId);
  });

  socket.on("castCard", ({roomId,cardId,target})=>{
    const room = rooms[roomId];
    const hand = room.state.hands[socket.id];
    const i = hand.findIndex(c=>c.id===cardId);
    if(i===-1) return;

    const card = hand[i];
    if(!canPayCost(room.state.manaPool[socket.id], card.manaCost)) return;

    payCost(room.state.manaPool[socket.id], card.manaCost);
    hand.splice(i,1);

    room.stack.push({card,target});
    startPriority(room);
    emitRoom(roomId);
  });

  socket.on("passPriority", ({roomId})=>{
    const room = rooms[roomId];
    room.priority.passes++;

    if(room.priority.passes >= room.players.length){
      resolveStack(room);
      room.priority.passes = 0;
    } else {
      room.priority.currentIndex =
        (room.priority.currentIndex+1)%room.priority.order.length;
    }

    emitRoom(roomId);
  });

});

function emitRoom(roomId){
  const room = rooms[roomId];
  room.players.forEach(p=>{
    io.to(p.id).emit("roomUpdate",{
      players: room.players,
      battlefield: room.state.battlefield,
      graveyard: room.state.graveyard,
      hand: room.state.hands[p.id],
      manaPool: room.state.manaPool,
      turn: room.turn,
      stack: room.stack,
      priority: room.priority
    });
  });
}

server.listen(3000);
