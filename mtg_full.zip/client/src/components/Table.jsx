
import {useState} from "react";
import {socket} from "../socket";

export default function Table({room}){
  const [target,setTarget]=useState(null);
  const playerId = socket.id;

  function cast(card,targetId){
    socket.emit("castCard",{roomId:"sala1",cardId:card.id,target:targetId});
    setTarget(null);
  }

  return (
    <div>
      <h3>Battlefield</h3>
      {room.battlefield.map(c=>(
        <img key={c.id} src={c.image} width={80}
          onClick={()=>target && cast(target,c.id)} />
      ))}

      <h3>Hand</h3>
      {room.hand?.map(c=>(
        <img key={c.id} src={c.image} width={80}
          onClick={()=>setTarget(c)} />
      ))}

      <h3>Mana</h3>
      <pre>{JSON.stringify(room.manaPool[playerId],null,2)}</pre>
    </div>
  );
}
