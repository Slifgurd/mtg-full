
export function parseManaCost(m){
  const r={W:0,U:0,B:0,R:0,G:0,C:0};
  const matches = m?.match(/{.*?}/g)||[];
  matches.forEach(s=>{
    const v=s.replace(/[{}]/g,"");
    if(r[v]!==undefined) r[v]++;
    else if(!isNaN(v)) r.C+=Number(v);
  });
  return r;
}
